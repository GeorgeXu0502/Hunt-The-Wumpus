﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HuntTheWumpus_Player___HighScore_Test___George_Xu
{
    internal class Player_HighScore
    {
        public Player_HighScore()
        {

        }
    }
}

namespace HuntTheWumpus_Player___HighScore_Test___George_Xu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Player_HighScore PlayerHighScore;

        private void buttonConstructor_Click(object sender, EventArgs e)
        {
            PlayerHighScore = new Player_HighScore();
        }
    }
}
